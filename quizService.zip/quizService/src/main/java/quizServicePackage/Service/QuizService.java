package quizServicePackage.Service;

import quizServicePackage.model.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import quizServicePackage.Dao.*;
import quizServicePackage.model.QuestionWrapper;
import quizServicePackage.model.Quiz;

@Service 
public class QuizService {
	
	@Autowired
	QuizDoa quizDoa;
//	@Autowired
//	QuestionDao questionDao;

	public ResponseEntity<String> createQuiz(String category, int numb, String title) {
		// TODO Auto-generated method stub
//		List<Questions> questions =questionDao.findRandomQuestionsByCategory(category,numb);
//		Quiz qz=new Quiz();
//		qz.setTitle(title);
//		qz.setQuestions(questions);
//		quizDoa.save(qz);
		return new ResponseEntity<>("Successs",HttpStatus.CREATED);
	}

	public ResponseEntity<List<QuestionWrapper>> getQuestions(Integer id) {
		// TODO Auto-generated method stub
		Optional<Quiz> qz=quizDoa.findById(id);
//		List<Questions> questionsfromDB=qz.get().getQuestions();
		List<QuestionWrapper> questionsforUser=new ArrayList<>();
//		for(Questions q:questionsfromDB)
//		{
//			QuestionWrapper qw= new QuestionWrapper(q.getId(),q.getQuestionTitle(),q.getOption1(),q.getOption2(),q.getOption3(),q.getOption4());
//			questionsforUser.add(qw);
//		}
		return new ResponseEntity<>(questionsforUser,HttpStatus.OK);
		
	}

	public ResponseEntity<Integer> calculateResult(Integer id, List<Response> responses) {
		// TODO Auto-generated method stub
		Quiz quiz=quizDoa.findById(id).get();
//		List<Questions> questions=quiz.getQuestions();
		int right=0;
//		int i=0;
//		for(Response response:responses)
//		{
////			System.out.println(response.getResponse());
//			if(response.getResponse().equals(questions.get(i).getRightAnswer()))
//				right+=1;
//			i+=1;
//		}
		return new ResponseEntity<>(right,HttpStatus.OK);
	}

}
