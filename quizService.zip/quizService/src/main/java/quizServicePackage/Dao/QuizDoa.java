package quizServicePackage.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import quizServicePackage.model.Quiz;

public interface QuizDoa extends JpaRepository<Quiz,Integer>{
	

}
